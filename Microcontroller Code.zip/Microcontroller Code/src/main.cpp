#include <Arduino.h>
#include <Servo.h>

#define BOT 2
#define S1 6
#define S2 9
#define S3 10
#define S4 11

void Interrupt();
void Function1();
void Function2();
void Function3();
void Function4(int val);
void Function5(int val);
void Function6(int val);
void Function7(int val);
void DecodeMessage();
void command(int com, int val);
void ProcessMessage(char* message);
void moveServo(Servo& servo, int servoPos, int &servoValue);

//Declaração dos servos motores
Servo servo1;
Servo servo2;
Servo servo3;
Servo servo4;

//Ângulos posição inicial
int servo1Inicial = 90;
int servo2Inicial = 67;
int servo3Inicial = 20;
int servo4Inicial = 74;
//Variáveis para controle dos valores dos servos
int servo1Value = servo1Inicial;
int servo2Value = servo2Inicial;
int servo3Value = servo3Inicial;
int servo4Value = servo4Inicial;   

//Variáveis para controle das mensagens
const int MAX_MESSAGE_LENGTH = 5;     //Tamanho da mensagem
char message[MAX_MESSAGE_LENGTH];     //Vetor para armazanamento da mensagem
int messageIndex = 0;                 //Variável para controle do vetor de mensagem
boolean messageStarted = false;       //Controle do começo da tranmissão
boolean interrupt = false;

void setup() {
  Serial.begin(9600);
  servo1.attach(S1);  
  servo2.attach(S2);  
  servo3.attach(S3);  
  servo4.attach(S4);
  servo4.write(servo4Inicial);
  servo3.write(servo3Inicial);
  servo2.write(servo2Inicial);
  servo1.write(servo1Inicial);
  pinMode(BOT, INPUT_PULLUP);  
  attachInterrupt(digitalPinToInterrupt(BOT), Interrupt, FALLING);
}

void loop(){
  if(interrupt == true){
    moveServo(servo1, servo1Inicial, servo1Value);
    moveServo(servo2, servo2Inicial, servo2Value);
    moveServo(servo3, servo3Inicial, servo3Value);
    moveServo(servo4, servo4Inicial, servo4Value);
    interrupt = false;
  }   
  DecodeMessage();
}

//função para captar as mensagens e decodifica-las
void DecodeMessage(){
  while (Serial.available() > 0) {
    char incomingByte = Serial.read();

    if (incomingByte == '<') {
      // Inicio da mensagem      
      messageIndex = 0;
      messageStarted = true;
    } else if (incomingByte == '>') {
      // Fim da mensagem            
      if (messageStarted) {
        message[messageIndex] = '\0';               // Adiciona o caractere nulo ao final da mensagem  
        if(messageIndex >= MAX_MESSAGE_LENGTH-1){           
            ProcessMessage(message);                //Se a mensagem estiver no padrão estabelecido é enviada para processamento
        }
        messageStarted = false;               
      }
    } else if (messageStarted) {
      // Lendo os dados da mensagem
      message[messageIndex] = incomingByte;
      messageIndex++;

      if (messageIndex >= MAX_MESSAGE_LENGTH) {
        // Limite máximo da mensagem atingido, reinicia
        messageStarted = false;
      }
    }    
  }
}
//Converte os valores char da mensagem para inteiro
void ProcessMessage(char* message){
  int com = message[0] - '0';
  int val = ((message[1] - '0')*100) + ((message[2] - '0')*10) + (message[3] - '0') ;  
  //Envia para o comando, que determina qual funcao deve ser executada
  command(com, val);
}

//Função comando
void command(int com, int val){  
  switch (com){
    case 1:
      Function1();      
      break;
    case 2:
      Function2();
      break;
    case 3:
      Function3();
      break;
    case 4:
      Function4(val);
      break;
    case 5:
      Function5(val);
      break;
    case 6:
      Function6(val);
      break;
    case 7:
      Function7(val);
      break; 
    default:      
      break;    
  }
}

void Interrupt(){  
  interrupt = true;  
}

void moveServo(Servo& servo, int servoPos, int &servoValue) {
  if (servoValue > servoPos) {
    for (int i = servoValue; i >= servoPos; i--) {
      servo.write(i);
      servoValue = i;
      delay(10);      
    }
  } else {
    for (int i = servoValue; i <= servoPos; i++) {
      servo.write(i);
      servoValue = i;      
      delay(10);
    }
  }
}

//Função para o botão 1 da interface
void Function1(){    
  moveServo(servo4, servo4Inicial, servo4Value); 
  moveServo(servo3, servo3Inicial, servo3Value);
  moveServo(servo2, servo2Inicial, servo2Value);
  moveServo(servo1, servo1Inicial, servo1Value);   
}

//Função para o botão 2 da interface
void Function2(){
  Function1();
  //4 104 1 61 2 64 3 68
  moveServo(servo4, 104, servo4Value); 
  moveServo(servo1, 61, servo1Value);
  moveServo(servo2, 64, servo2Value);
  moveServo(servo3, 68, servo3Value);  
  moveServo(servo4, 74, servo4Value);  
}

//Função para o botão 3 da interface
void Function3(){
  Function1();
  moveServo(servo1, 125, servo1Value);
  moveServo(servo2, 77, servo2Value);
  moveServo(servo3, 59, servo3Value);
  moveServo(servo4, 107, servo4Value);
}

//Função para o slider da interface que controla o servo 1
void Function4(int val){  
  Serial.print("Executando Função 4: Servo 1 ângulo: ");
  Serial.println(val);
  servo1.write(val);
  servo1Value = val;
}

//Função para o slider da interface que controla o servo 2
void Function5(int val){   
  Serial.print("Executando Função 5: Servo 2 ângulo: ");  
  Serial.println(val);
  servo2.write(val);
  servo2Value = val;
}

//Função para o slider da interface que controla o servo 3
void Function6(int val){   
  Serial.print("Executando Função 6: Servo 3 ângulo: ");
  Serial.println(val);
  servo3.write(val);
  servo3Value = val;
}

//Função para o slider da interface que controla o servo 4
void Function7(int val){  
  Serial.print("Executando Função 7: Servo 4 ângulo: ");
  Serial.println(val);
  servo4.write(val);
  servo4Value = val;
}