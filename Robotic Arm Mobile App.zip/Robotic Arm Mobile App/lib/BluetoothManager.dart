import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:shared_preferences/shared_preferences.dart';

int DelayMessage = 50;

class BluetoothAppState extends ChangeNotifier {
  int _bluetoothState = 1;
  BluetoothDevice?
      _connectedDevice; // Adicionado para armazenar o dispositivo conectado

  int getBluetoothState() {
    return _bluetoothState;
  }

  BluetoothDevice? getConnectedDevice() {
    return _connectedDevice;
  }

  void setBluetoothState(int state) {
    _bluetoothState = state;
    _saveBluetoothState(state);
    notifyListeners();
  }

  void setConnectedDevice(BluetoothDevice? device) {
    _connectedDevice = device;
    notifyListeners();
  }

  Future<void> _saveBluetoothState(int state) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt('_bluetoothState', state);
  }

  Future<void> loadBluetoothState() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    int savedBluetoothState = prefs.getInt('_bluetoothState') ?? 1;
    _bluetoothState = savedBluetoothState;
    notifyListeners();
  }
}

class BluetoothManager {
  BluetoothConnection? _connection;
  List<BluetoothDevice> _devicesList = [];
  BluetoothAppState _appState;

  DateTime? _lastMessageTime;
  final Duration _messageInterval = Duration(milliseconds: DelayMessage);

  BluetoothManager(this._appState);

  Future<List<BluetoothDevice>> getBondedDevices() async {
    _devicesList = await FlutterBluetoothSerial.instance.getBondedDevices();
    return _devicesList;
  }

  Future<void> connectToDevice(BluetoothDevice device) async {
    if (isBluetoothConnected() == false) {
      _appState.setBluetoothState(3);
    }
    try {
      _connection = await BluetoothConnection.toAddress(device.address);
      _appState.setBluetoothState(2);
      _appState.setConnectedDevice(device); // Define o dispositivo conectado
    } catch (e) {
      _appState.setBluetoothState(1);
    }
  }

  Future<void> disconnectFromDevice() async {
    try {
      await _connection!.finish();
      _appState.setBluetoothState(1);
      _appState.setConnectedDevice(null); // Remove o dispositivo conectado
    } catch (e) {}
  }

  bool isBluetoothConnected() {
    return _connection != null && _connection!.isConnected;
  }

  void checkBluetoothConnection() {
    Timer.periodic(const Duration(seconds: 2), (timer) {
      bool isConnected = isBluetoothConnected();
      if (isConnected && _appState.getBluetoothState() == 1) {
        _appState.setBluetoothState(2);
      } else if (!isConnected && _appState.getBluetoothState() == 2) {
        _appState.setBluetoothState(1);
        _appState.setConnectedDevice(null);
      }
    });
  }

  void sendMessage(int Command, {int Valor = 0}) async {
    String message = ProtocolMessage(Command, Valor: Valor);
    if (isBluetoothConnected() == true && _canSendMessage()) {
      _lastMessageTime = DateTime.now();
      List<int> bytes = message.codeUnits;
      Uint8List uint8List = Uint8List.fromList(bytes);
      _connection?.output.add(uint8List);
      await _connection?.output.allSent;
    }
  }

  bool _canSendMessage() {
    if (_lastMessageTime == null) {
      return true;
    }
    DateTime currentTime = DateTime.now();
    DateTime nextMessageTime = _lastMessageTime!.add(_messageInterval);
    return currentTime.isAfter(nextMessageTime);
  }

  String ProtocolMessage(int Command, {int Valor = 0}) {
    switch (Command) {
      case 1:
      case 2:
      case 3:
        return '<${Command}000>';
      case 4:
      case 5:
      case 6:
      case 7:
        if (Valor < 10) {
          return '<${Command}00$Valor>';
        } else if (Valor < 100) {
          return '<${Command}0$Valor>';
        } else {
          return '<$Command$Valor>';
        }
      default:
        return '<0000>';
    }
  }
}
