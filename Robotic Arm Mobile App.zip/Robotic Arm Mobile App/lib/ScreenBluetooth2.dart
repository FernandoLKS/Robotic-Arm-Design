import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:provider/provider.dart';

import 'BluetoothManager.dart';

class BluetoothApp extends StatefulWidget {
  final BluetoothManager BManager;
  final BluetoothAppState appState;

  const BluetoothApp({Key? key, required this.BManager, required this.appState})
      : super(key: key);

  @override
  _BluetoothAppState createState() => _BluetoothAppState();
}

class _BluetoothAppState extends State<BluetoothApp>
    with WidgetsBindingObserver {
  List<BluetoothDevice> _devicesList = [];

  @override
  void initState() {
    super.initState();
    _getDevicesList();
    widget.BManager.checkBluetoothConnection();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.detached) {
      widget.BManager.disconnectFromDevice();
    }
  }

  Future<void> ActionClick(BluetoothDevice device) async {
    bool isConnected = widget.BManager.isBluetoothConnected();
    if (isConnected == false) {
      await widget.BManager.connectToDevice(device);
      if (widget.BManager.isBluetoothConnected() == true) {
        setState(() {
          widget.appState.setBluetoothState(2);
        });
      }
    } else if (isConnected == true) {
      await widget.BManager.disconnectFromDevice();
      if (widget.BManager.isBluetoothConnected() == false) {
        setState(() {
          widget.appState.setBluetoothState(1);
        });
      }
    } else {}
  }

  void _getDevicesList() async {
    List<BluetoothDevice> devices = await widget.BManager.getBondedDevices();
    setState(() {
      _devicesList = devices;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<BluetoothAppState>.value(
      value: widget.appState,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Bluetooth'),
          backgroundColor: const Color.fromARGB(255, 199, 129, 0),
          actions: <Widget>[
            Consumer<BluetoothAppState>(
              builder: (context, appState, _) {
                if (widget.appState.getBluetoothState() != 3) {
                  return IconButton(
                    icon: const Icon(Icons.home),
                    onPressed: () {
                      Navigator.pushReplacementNamed(context, '/primary');
                    },
                  );
                }
                return Container();
              },
            ),
          ],
        ),
        body: Column(
          children: [
            ElevatedButton(
              onPressed: _getDevicesList,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 59, 59, 59),
              ),
              child: const Text('Buscar Dispositivos Bluetooth'),
            ),
            Consumer<BluetoothAppState>(
              builder: (context, appState, _) {
                return Text(
                  widget.appState.getBluetoothState() == 2
                      ? 'Conectado'
                      : widget.appState.getBluetoothState() == 1
                          ? 'Desconectado'
                          : 'Conectando...',
                  style: TextStyle(
                    fontSize: 20,
                    color: widget.appState.getBluetoothState() == 2
                        ? Colors.green
                        : widget.appState.getBluetoothState() == 1
                            ? Colors.red
                            : Colors.blue,
                  ),
                );
              },
            ),
            Expanded(
              child: Consumer<BluetoothAppState>(
                builder: (context, appState, _) {
                  return ListView.builder(
                    itemCount: _devicesList.length,
                    itemBuilder: (context, index) {
                      final device = _devicesList[index];
                      return ListTile(
                        title: Text(
                          device.name ?? 'Nome Desconhecido',
                          style: TextStyle(
                            color: device == widget.appState.getConnectedDevice()
                                ? Colors.green
                                : null,
                          ),
                        ),
                        subtitle: Text(device.address),
                        onTap: () async {
                          ActionClick(device);
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}