import 'package:flutter/material.dart';
import 'Servo.dart';
import 'BluetoothManager.dart';

class HomePage extends StatefulWidget {
  final BluetoothManager BManager;
  final BluetoothAppState appState;

  const HomePage({Key? key, required this.BManager, required this.appState})
      : super(key: key);

  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    widget.BManager.checkBluetoothConnection();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {    
    if (state == AppLifecycleState.detached) {
      widget.BManager.disconnectFromDevice();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Controller Robotic Arm'),
        backgroundColor: const Color.fromARGB(255, 199, 129, 0),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.bluetooth),
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/second');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          // Botões das funções
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              for (int i = 0; i < 3; i++)
                ElevatedButton.icon(
                  onPressed: () async {
                    widget.BManager.sendMessage(i + 1);
                  },
                  icon: const Icon(Icons.switch_left),
                  label: Text('Função ${i + 1}'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 59, 59, 59),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 25),
          // Barras para controle dos Motores
          for (int i = 0; i < ListServos.length; i++)
            Column(
              children: [
                Text(
                  'Motor ${i + 1} (${ListServos[i].value})',
                  style: const TextStyle(
                      fontSize: 15.0, color: Color.fromARGB(255, 43, 43, 43)),
                ),
                Slider(
                  value: ListServos[i].value.toDouble(),
                  min: ListServos[i].min.toDouble(),
                  max: ListServos[i].max.toDouble(),
                  onChanged: (double newValue) async {
                    int newValueInt = newValue.round();
                    widget.BManager.sendMessage(i + 4, Valor: newValueInt);                    
                    setState(() {
                      ListServos[i].value = newValue.round();
                    });
                  },
                  activeColor: const Color.fromARGB(255, 77, 77, 77),
                  inactiveColor: const Color.fromARGB(255, 204, 153, 14),
                ),
              ],
            ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Center(
                child: Image.asset('assets/images/RoboticARM.png'),
              ),
            ],
          )
        ],
      ),
    );
  }
}
