// Classe para os Servos
class Servo {
  final String id;
  int value;
  final int min;
  final int max;

  Servo({
    required this.id,
    required this.value,
    required this.min,
    required this.max,
  });

  // Função para atualizar os servos
  void updateServoValue(String id, int value) {
    for (int i = 0; i < ListServos.length; i++) {
      if (ListServos[i].id == id) {
        ListServos[i].value = value;
        break;
      }
    }
  }
}

// Instância e Calibração dos servos
List<Servo> ListServos = [
  Servo(id: "Motor1", value: 90, min: 0, max: 180),
  Servo(id: "Motor2", value: 61, min: 43, max: 79),
  Servo(id: "Motor3", value: 61, min: 20, max: 102),
  Servo(id: "Motor4", value: 114, min: 66, max: 162),
];
