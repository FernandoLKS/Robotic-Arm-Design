import 'package:flutter/material.dart';
import 'BluetoothManager.dart';
import 'ScreenBluetooth2.dart';
import 'ScreenRoboticARM2.dart';


void main() {    
  final BluetoothAppState appState = BluetoothAppState();
  final BluetoothManager BManager = BluetoothManager(appState);  
  runApp(
    MaterialApp(   
      routes: {
        '/primary': (context) => HomePage(BManager: BManager, appState:appState),
        '/second': (context) => BluetoothApp(BManager: BManager, appState:appState),
      },
      initialRoute: '/primary',  
      theme: ThemeData(        
        brightness: Brightness.light,
      ),      
    )
  );
}
